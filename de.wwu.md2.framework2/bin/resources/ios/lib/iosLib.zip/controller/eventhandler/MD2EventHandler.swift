//
//  MD2EventHandler.swift
//  md2-ios-library
//
//  Created by Christoph Rieger on 23.07.15.
//  Copyright (c) 2015 Christoph Rieger. All rights reserved.
//

/// MD2 event handler interface
protocol MD2EventHandler: class {
    
}