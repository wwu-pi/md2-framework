//
//  MD2Filter.swift
//  md2-ios-library
//
//  Created by Christoph Rieger on 22.07.15.
//  Copyright (c) 2015 Christoph Rieger. All rights reserved.
//


/// Filter a set of entities
class MD2Filter {
    // TODO implementation
}
