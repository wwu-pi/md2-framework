// static: Controllers
//
//  HelpViewController.h
//  Tarifrechner
//
//  Created by Uni Münster on 08.05.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Controller.h"

@interface HelpController : Controller

-(void) setHelpText: (NSString *) text;

@end