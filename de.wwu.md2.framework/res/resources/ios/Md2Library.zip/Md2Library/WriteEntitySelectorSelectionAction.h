// static: Actions
//
//  WriteEntitySelectorSelectionAction.h
//  TariffCalculator
//
//  Created by Uni Münster on 28.08.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Action.h"
#import "WriteEntitySelectorSelectionEvent.h"

@interface WriteEntitySelectorSelectionAction : Action
@end