// static: Actions
//
//  GotoWorkflowAction.h
//  TariffCalculator
//
//  Created by Uni Münster on 29.08.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Action.h"
#import "GotoWorkflowEvent.h"

@interface GotoWorkflowAction : Action
@end