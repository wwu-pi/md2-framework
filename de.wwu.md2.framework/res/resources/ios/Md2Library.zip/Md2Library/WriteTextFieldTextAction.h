// static: Actions
//
//  WriteTextFieldTextAction.h
//  TariffCalculator
//
//  Created by Uni Münster on 17.06.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Action.h"
#import "WriteTextFieldTextEvent.h"

@interface WriteTextFieldTextAction : Action
@end