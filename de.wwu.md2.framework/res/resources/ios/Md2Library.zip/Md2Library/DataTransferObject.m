// static: DTOs
//
//  DataTransferObject.m
//  TariffCalculator
//
//  Created by Uni Münster on 08.08.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "DataTransferObject.h"

@implementation DataTransferObject

@dynamic createdDate;
@dynamic identifier;

@end