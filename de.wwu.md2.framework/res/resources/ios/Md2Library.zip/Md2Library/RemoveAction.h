// static: Actions
//
//  RemoveAction.h
//  TariffCalculator
//
//  Created by Uni Münster on 04.08.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Action.h"
#import "RemoveEvent.h"

@interface RemoveAction : Action
@end