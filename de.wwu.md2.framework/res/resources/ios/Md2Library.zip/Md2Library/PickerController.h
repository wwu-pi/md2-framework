// static: Controllers
//
//  PickerController.h
//  TariffCalculator
//
//  Created by Uni Münster on 01.06.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Controller.h"

@interface PickerController : Controller

-(void) setComboboxWidget: (ComboboxWidget *) widget;

@end