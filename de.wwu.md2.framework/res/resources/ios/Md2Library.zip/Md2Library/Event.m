// static: Events
//
//  Event.m
//  TariffCalculator
//
//  Created by Uni Münster on 04.06.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Event.h"

@implementation Event

+(id) event
{
    return [[self alloc] init];
}

@end