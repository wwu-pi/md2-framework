// static: Layouts
//
//  GridLayout.h
//  TariffCalculator
//
//  Created by Uni Münster on 15.06.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Layout.h"

@interface GridLayout : Layout
@end